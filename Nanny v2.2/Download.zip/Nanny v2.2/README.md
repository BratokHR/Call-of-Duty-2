# Nanny for Call of Duty 2 (1.0)
---
### Video link: **https://www.youtube.com/watch?v=YNo8zq921-Y**

### Standart commands:
- !cmdlist - writes in console all commands;
- !time - shows the current time;
- !id - writes in chat current id player;
- !kick - kick the player;
- !login - sign in;
- !save.rcon - saves rcon password;
- !save.say - saves say command;
- !save.symbol - saves first symbol for commands;
#### Sign in:
```
!save.rcon password
!login
```
### Kick player `pon4ik`
```
!kick 4ik 
or
!kick pon
or 
!kick pon4ik
...
```