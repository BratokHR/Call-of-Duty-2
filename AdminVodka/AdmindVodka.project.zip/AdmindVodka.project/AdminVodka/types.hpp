#include <Windows.h>

typedef float vec_t;
typedef vec_t vec4_t[4];