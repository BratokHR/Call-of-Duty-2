#include <Windows.h>
#include <detours.h>
#include <string>
#include <vector>
#include <regex>

#include "DrawEngine\cDraw.h"
#include "Engine.hpp"
#include "Memory.hpp"
#include "dllmain.hpp"